﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcPublicacoes.Models
{
    public class QtdPublicacoesLocal
    {
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public long quantidade { get; set; }
        public string Localizacao { get; set; }
    }
}